// Vercel serverless function — /api/submit-dp360
// Receives lead from DP360 Gestão LP (dp360gestao.com.br)
// → Appends to Google Sheets
// → Sends WhatsApp to DP360 ads group via Z-API (guarded, Fase 2)

const ZAPI_INSTANCE     = process.env.ZAPI_INSTANCE;
const ZAPI_TOKEN        = process.env.ZAPI_TOKEN;
const ZAPI_CLIENT_TOKEN = process.env.ZAPI_CLIENT_TOKEN;
const DP360_GROUP_ID    = process.env.DP360_GROUP_ID;
const SHEET_ID          = process.env.DP360_SHEET_ID;

function getGoogleSA() {
  try {
    const sa = JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT || '{}');
    if (sa.private_key) sa.private_key = sa.private_key.replace(/\\n/g, '\n');
    return sa;
  } catch (e) {
    console.error('SA parse error:', e);
    return {};
  }
}

async function getGoogleToken() {
  const { createSign } = await import('crypto');
  const sa = getGoogleSA();
  const now = Math.floor(Date.now() / 1000);
  const header  = Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })).toString('base64url');
  const payload = Buffer.from(JSON.stringify({
    iss: sa.client_email,
    scope: 'https://www.googleapis.com/auth/spreadsheets',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now,
  })).toString('base64url');

  const sign = createSign('RSA-SHA256');
  sign.update(`${header}.${payload}`);
  const sig = sign.sign(sa.private_key, 'base64url');
  const jwt = `${header}.${payload}.${sig}`;

  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}`,
  });
  const data = await res.json();
  return data.access_token;
}

async function appendToSheet(token, row) {
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/Leads!A:L:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ values: [row] }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Sheets append failed: ${res.status} ${text}`);
  }
}

async function countThisMonth(token) {
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/Leads!A:A`;
  const res = await fetch(url, { headers: { 'Authorization': `Bearer ${token}` } });
  const data = await res.json();
  const rows = data.values || [];
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Fortaleza' }));
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const yyyy = now.getFullYear();
  const monthMark = `/${mm}/${yyyy}`;
  return rows.filter(r => r[0] && r[0].includes(monthMark)).length + 1;
}

async function zapiSend(phone, message) {
  const url = `https://api.z-api.io/instances/${ZAPI_INSTANCE}/token/${ZAPI_TOKEN}/send-text`;
  await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Client-Token': ZAPI_CLIENT_TOKEN },
    body: JSON.stringify({ phone, message }),
  });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const {
    nome, whatsapp, escritorio, cnpjs, vidas,
    utm_source, utm_campaign, utm_content, utm_medium, utm_term
  } = req.body || {};

  if (!nome || !whatsapp || !escritorio || !cnpjs || !vidas) {
    return res.status(400).json({ error: 'Campos obrigatórios ausentes' });
  }

  const dataBR = new Date().toLocaleString('pt-BR', { timeZone: 'America/Fortaleza' });
  const telClean = whatsapp.replace(/\D/g, '');
  const telLink = telClean.startsWith('55') ? `+${telClean}` : `+55${telClean}`;

  let count = 1;
  try {
    const token = await getGoogleToken();
    count = await countThisMonth(token);
    await appendToSheet(token, [
      dataBR,
      nome,
      whatsapp,
      escritorio,
      cnpjs,
      vidas,
      utm_source || '',
      utm_campaign || '',
      utm_content || '',
      utm_medium || '',
      utm_term || '',
      'dp360gestao.com.br'
    ]);
  } catch (e) {
    console.error('Sheets error:', e);
  }

  if (DP360_GROUP_ID && ZAPI_INSTANCE && ZAPI_TOKEN && ZAPI_CLIENT_TOKEN) {
    const msgGrupo =
      `*Novo lead DP360 #${count}*\n\n` +
      `*Nome:* ${nome}\n` +
      `*WhatsApp:* ${telLink}\n` +
      `*Escritório:* ${escritorio}\n` +
      `*CNPJs atendidos:* ${cnpjs}\n` +
      `*Vidas:* ${vidas}` +
      (utm_source ? `\n\n*Fonte:* ${utm_source}` : '') +
      (utm_campaign ? `\n*Campanha:* ${utm_campaign}` : '') +
      (utm_content ? `\n*Criativo:* ${utm_content}` : '') +
      `\n\n_${dataBR} · dp360gestao.com.br_`;
    try {
      await zapiSend(DP360_GROUP_ID, msgGrupo);
    } catch (e) {
      console.error('WhatsApp error:', e);
    }
  }

  return res.status(200).json({ ok: true });
}
